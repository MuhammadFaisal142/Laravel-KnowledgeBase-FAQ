<?php

return [
    'password' => 'As senhas devem ter pelo menos seis caracteres e corresponder à confirmação.',
    'reset'    => 'Sua senha foi redefinida!',
    'sent'     => 'Enviamos por e-mail o link para redefinição de senha!',
    'token'    => 'Este token de redefinição de senha é inválido.',
    'user'     => 'Não encontramos nenhum usuário com esse endereço de e-mail.',
    'updated'  => 'Sua senha foi alterada!',
];
