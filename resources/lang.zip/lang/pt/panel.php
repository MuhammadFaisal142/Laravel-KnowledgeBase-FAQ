<?php

return [
    'site_title' => 'Consultores MMW',
];